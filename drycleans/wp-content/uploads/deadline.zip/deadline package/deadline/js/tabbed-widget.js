$(document).ready(function() {
  $("#tabs").tabs({ fx: { height: 'toggle', opacity: 'toggle' } });
});
